SET NAMES 'UTF8';

DROP TABLE IF EXISTS msys_id;

CREATE TABLE msys_id (
    
    mkey varchar(255),
    m_id INTEGER,
     version INTEGER,  CreateDatetime timestamp, Active bit,UpdateRef VARCHAR(255)
    

	  
) ;