SET NAMES 'UTF8';

DROP TABLE IF EXISTS mfeedspecial;

CREATE TABLE mfeedspecial (
    brid bigint,
    MonthNu  INTEGER
,
     version INTEGER,  CreateDatetime timestamp, Active bit,UpdateRef VARCHAR(255)
    

	  
) ;