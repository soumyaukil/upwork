SET NAMES 'UTF8';

DROP TABLE IF EXISTS mtktcharge;

CREATE TABLE mtktcharge (
    brid bigint,
    MonthNu  INTEGER
,
     version INTEGER,  CreateDatetime timestamp, Active bit,UpdateRef VARCHAR(255)
    

	  
) ;