SET NAMES 'UTF8';

DROP TABLE IF EXISTS msys_info;

CREATE TABLE msys_info (
    
    id varchar(255),
    subid varchar(255),
     version INTEGER,  CreateDatetime timestamp, Active bit,UpdateRef VARCHAR(255)
    

	  
) ;