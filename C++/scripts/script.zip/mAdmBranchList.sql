SET NAMES 'UTF8';

DROP TABLE IF EXISTS mAdmBranchList;

CREATE TABLE mAdmBranchList (
    trid INTEGER,
    brid  INTEGER,
    stat1 INTEGER,
     version INTEGER,  CreateDatetime timestamp, Active bit,UpdateRef VARCHAR(255)
    

	  
) ;