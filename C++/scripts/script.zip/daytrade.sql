CREATE TABLE daytrades(
   080008000                  VARCHAR(12) NOT NULL PRIMARY KEY
  ,SMAT                       VARCHAR(4) NOT NULL
  ,APVO                       VARCHAR(5) NOT NULL
  ,SS                         VARCHAR(2) NOT NULL
  ,200                        INTEGER  NOT NULL
  ,245000                     NUMERIC(9,5) NOT NULL
  ,MBS03975                   VARCHAR(9) NOT NULL
  ,1122041657519216814        VARCHAR(31)
  ,O54                        VARCHAR(12) NOT NULL
  ,T1                         VARCHAR(6) NOT NULL
  ,FIELD11                    VARCHAR(13)
);